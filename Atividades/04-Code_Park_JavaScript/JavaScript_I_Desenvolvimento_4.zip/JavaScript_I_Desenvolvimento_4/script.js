let print = () => console.log ("Conexão feita com sucesso!")

for(let i=0; i<3; i++){
    print()
}
